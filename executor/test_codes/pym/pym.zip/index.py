import uuid
import numpy as np


def handle(input):
    return "Hello " + input
