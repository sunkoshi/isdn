#include <iostream>
using namespace std;
#include "index.h"
string handle(string input)
{
    return "Hey its working! " + input;
}