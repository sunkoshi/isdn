#include <iostream>
using namespace std;
string handle(string input);