const { sum } = require("./sum");
console.log(sum(3, 4));
