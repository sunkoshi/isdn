def handle(input):
    return "Amigo! " + input
