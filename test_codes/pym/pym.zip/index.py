import uuid
import numpy as np


def handle(input):
    return uuid.uuid4().__str__()
